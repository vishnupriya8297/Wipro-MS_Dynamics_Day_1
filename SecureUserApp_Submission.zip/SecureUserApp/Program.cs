using SecureUserApp.Services;
class Program
{
    static void Main()
    {
        LoggerService.Configure();
        var auth = new AuthService();
        auth.Register("admin","Secure@123");
        Console.WriteLine(auth.Authenticate("admin","Secure@123"));
    }
}