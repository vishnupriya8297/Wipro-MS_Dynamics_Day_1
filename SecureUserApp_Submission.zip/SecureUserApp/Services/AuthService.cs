using SecureUserApp.Models;
namespace SecureUserApp.Services
{
    public class AuthService
    {
        private readonly Dictionary<string, User> _users = new();
        public void Register(string u,string p)=>_users[u]=new User{Username=u,HashedPassword=CryptoService.HashPassword(p)};
        public bool Authenticate(string u,string p)=>_users.ContainsKey(u)&&_users[u].HashedPassword==CryptoService.HashPassword(p);
    }
}