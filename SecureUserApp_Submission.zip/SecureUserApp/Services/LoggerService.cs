using Serilog;
namespace SecureUserApp.Services
{
    public static class LoggerService
    {
        public static void Configure()
        {
            Log.Logger=new LoggerConfiguration().WriteTo.File("logs/app.log").CreateLogger();
        }
    }
}