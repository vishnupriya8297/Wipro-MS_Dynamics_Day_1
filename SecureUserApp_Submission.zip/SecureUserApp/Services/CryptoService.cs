using System.Security.Cryptography;
using System.Text;
namespace SecureUserApp.Services
{
    public static class CryptoService
    {
        public static string HashPassword(string password)
        {
            using var sha = SHA256.Create();
            return Convert.ToBase64String(sha.ComputeHash(Encoding.UTF8.GetBytes(password)));
        }
    }
}