using Xunit;
using SecureUserApp.Services;
public class AuthTests
{
    [Fact]
    public void Login_Works()
    {
        var a=new AuthService();
        a.Register("u","p");
        Assert.True(a.Authenticate("u","p"));
    }
}